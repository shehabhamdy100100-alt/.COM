import { Calculator } from "./components/Calculator";

function App() {
  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-2 sm:p-4">
      <Calculator />
    </div>
  );
}

export default App;
import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Delete } from "lucide-react";
import { calculate, formatNumber } from "../utils/calculator";

type Operator = "+" | "-" | "×" | "÷" | null;

export function Calculator() {
  const [display, setDisplay] = useState("0");
  const [previousValue, setPreviousValue] = useState<string | null>(null);
  const [operator, setOperator] = useState<Operator>(null);
  const [waitingForOperand, setWaitingForOperand] = useState(false);
  const [history, setHistory] = useState("");

  const inputDigit = (digit: string) => {
    if (waitingForOperand) {
      setDisplay(digit);
      setWaitingForOperand(false);
    } else {
      setDisplay(display === "0" ? digit : display + digit);
    }
  };

  const inputDecimal = () => {
    if (waitingForOperand) {
      setDisplay("0.");
      setWaitingForOperand(false);
      return;
    }
    if (!display.includes(".")) {
      setDisplay(display + ".");
    }
  };

  const clear = () => {
    setDisplay("0");
    setPreviousValue(null);
    setOperator(null);
    setWaitingForOperand(false);
    setHistory("");
  };

  const handleOperator = (nextOperator: Operator) => {
    const inputValue = parseFloat(display);

    if (previousValue === null) {
      setPreviousValue(display);
      setHistory(`${display} ${nextOperator}`);
    } else if (operator) {
      const currentValue = parseFloat(previousValue);
      const newValue = calculate(currentValue, inputValue, operator);
      setDisplay(String(newValue));
      setPreviousValue(String(newValue));
      setHistory(`${newValue} ${nextOperator}`);
    }

    setWaitingForOperand(true);
    setOperator(nextOperator);
  };

  const calculateResult = () => {
    if (operator && previousValue !== null) {
      const inputValue = parseFloat(display);
      const previous = parseFloat(previousValue);
      const result = calculate(previous, inputValue, operator);
      setHistory(`${previousValue} ${operator} ${display} =`);
      setDisplay(String(result));
      setPreviousValue(null);
      setOperator(null);
      setWaitingForOperand(true);
    }
  };

  const toggleSign = () => {
    setDisplay(String(-parseFloat(display)));
  };

  const percentage = () => {
    setDisplay(String(parseFloat(display) / 100));
  };

  const backspace = () => {
    if (display.length > 1) {
      setDisplay(display.slice(0, -1));
    } else {
      setDisplay("0");
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key >= "0" && e.key <= "9") inputDigit(e.key);
      else if (e.key === ".") inputDecimal();
      else if (e.key === "+") handleOperator("+");
      else if (e.key === "-") handleOperator("-");
      else if (e.key === "*") handleOperator("×");
      else if (e.key === "/") handleOperator("÷");
      else if (e.key === "Enter" || e.key === "=") calculateResult();
      else if (e.key === "Escape") clear();
      else if (e.key === "Backspace") backspace();
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  });

  // Prevent zoom on double tap for mobile
  useEffect(() => {
    const preventZoom = (e: TouchEvent) => {
      if (e.touches.length > 1) {
        e.preventDefault();
      }
    };
    document.addEventListener("touchstart", preventZoom, { passive: false });
    return () => document.removeEventListener("touchstart", preventZoom);
  }, []);

  const buttons = [
    { label: "C", action: clear, className: "bg-red-500 active:bg-red-700 text-white" },
    { label: "±", action: toggleSign, className: "bg-slate-600 active:bg-slate-800 text-white" },
    { label: "%", action: percentage, className: "bg-slate-600 active:bg-slate-800 text-white" },
    { label: "÷", action: () => handleOperator("÷"), className: "bg-amber-500 active:bg-amber-700 text-white" },
    { label: "7", action: () => inputDigit("7"), className: "bg-slate-700 active:bg-slate-900 text-white" },
    { label: "8", action: () => inputDigit("8"), className: "bg-slate-700 active:bg-slate-900 text-white" },
    { label: "9", action: () => inputDigit("9"), className: "bg-slate-700 active:bg-slate-900 text-white" },
    { label: "×", action: () => handleOperator("×"), className: "bg-amber-500 active:bg-amber-700 text-white" },
    { label: "4", action: () => inputDigit("4"), className: "bg-slate-700 active:bg-slate-900 text-white" },
    { label: "5", action: () => inputDigit("5"), className: "bg-slate-700 active:bg-slate-900 text-white" },
    { label: "6", action: () => inputDigit("6"), className: "bg-slate-700 active:bg-slate-900 text-white" },
    { label: "-", action: () => handleOperator("-"), className: "bg-amber-500 active:bg-amber-700 text-white" },
    { label: "1", action: () => inputDigit("1"), className: "bg-slate-700 active:bg-slate-900 text-white" },
    { label: "2", action: () => inputDigit("2"), className: "bg-slate-700 active:bg-slate-900 text-white" },
    { label: "3", action: () => inputDigit("3"), className: "bg-slate-700 active:bg-slate-900 text-white" },
    { label: "+", action: () => handleOperator("+"), className: "bg-amber-500 active:bg-amber-700 text-white" },
    { label: "0", action: () => inputDigit("0"), className: "bg-slate-700 active:bg-slate-900 text-white col-span-2" },
    { label: ".", action: inputDecimal, className: "bg-slate-700 active:bg-slate-900 text-white" },
    { label: "=", action: calculateResult, className: "bg-emerald-500 active:bg-emerald-700 text-white" },
  ];

  return (
    <Card className="w-full max-w-sm bg-slate-800 border-slate-700 shadow-2xl rounded-3xl overflow-hidden mx-auto">
      <CardContent className="p-3 sm:p-6">
        {/* Header */}
        <div className="text-center mb-3 sm:mb-4">
          <h1 className="text-xl sm:text-2xl font-bold text-white mb-1">
            الآلة الحاسبة
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm">آلة حاسبة بسيطة وأنيقة</p>
        </div>

        {/* Display */}
        <div className="bg-slate-900 rounded-2xl p-3 sm:p-4 mb-3 sm:mb-4">
          <div className="text-slate-500 text-xs sm:text-sm h-5 sm:h-6 text-right font-mono truncate">
            {history}
          </div>
          <div className="text-white text-3xl sm:text-4xl font-bold text-right font-mono truncate">
            {formatNumber(display)}
          </div>
        </div>

        {/* Backspace Button */}
        <Button
          onClick={backspace}
          className="w-full mb-3 sm:mb-4 bg-slate-700 active:bg-slate-900 text-white rounded-xl h-12 sm:h-14 text-base sm:text-lg"
        >
          <Delete className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
          مسح رقم
        </Button>

        {/* Calculator Buttons */}
        <div className="grid grid-cols-4 gap-2 sm:gap-3">
          {buttons.map((btn, index) => (
            <Button
              key={index}
              onClick={btn.action}
              className={`${btn.className} h-14 sm:h-16 text-xl sm:text-2xl font-semibold rounded-xl transition-transform active:scale-95 touch-manipulation`}
            >
              {btn.label}
            </Button>
          ))}
        </div>

        {/* Keyboard hint for desktop */}
        <div className="hidden sm:block mt-4 text-center">
          <p className="text-slate-500 text-xs">
            💡 يمكنك استخدام لوحة المفاتيح للكتابة
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
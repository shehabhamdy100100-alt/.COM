export function Header() {
  return (
    <div className="mb-8 text-center">
      <h1 className="text-4xl font-bold text-white mb-2 tracking-tight">
        الآلة الحاسبة
      </h1>
      <p className="text-slate-400 text-sm">آلة حاسبة بسيطة وأنيقة</p>
    </div>
  );
}
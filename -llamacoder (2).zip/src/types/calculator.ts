export type Operator = "+" | "-" | "×" | "÷" | null;

export interface CalculatorState {
  display: string;
  previousValue: string | null;
  operator: Operator;
  waitingForOperand: boolean;
  history: string;
}
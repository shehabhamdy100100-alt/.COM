export function calculate(a: number, b: number, operator: string): number {
  switch (operator) {
    case "+":
      return a + b;
    case "-":
      return a - b;
    case "×":
      return a * b;
    case "÷":
      return b !== 0 ? a / b : 0;
    default:
      return b;
  }
}

export function formatNumber(num: string): string {
  const value = parseFloat(num);
  if (isNaN(value)) return "0";
  
  // Handle very large or very small numbers
  if (Math.abs(value) > 999999999) {
    return value.toExponential(4);
  }
  
  if (num.includes(".") && num.endsWith(".")) {
    return value.toLocaleString("en-US") + ".";
  }
  
  if (num.includes(".")) {
    const parts = num.split(".");
    return parseFloat(parts[0]).toLocaleString("en-US") + "." + parts[1];
  }
  
  return value.toLocaleString("en-US");
}